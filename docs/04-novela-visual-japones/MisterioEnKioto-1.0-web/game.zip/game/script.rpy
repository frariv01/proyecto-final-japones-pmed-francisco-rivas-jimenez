# =========================================
# MISTERIO EN KIOTO — 3 ESCENAS
# Ren'Py 8.x — VERSION SIN ERRORES
# =========================================

# =========================================
# VARIABLES
# =========================================

default social_credit = 0
default tatemae_balance = 0
default politeness_score = 0
default objective_completed = False
default scenes_passed = 0


# =========================================
# PERSONAJES
# =========================================

define waiter = Character("Camarero", color="#6b4f3a")


# =========================================
# ASSETS
# =========================================

image bg kyoto_tea_room = "game/images/kyoto_tea_room.png"
image bg kyoto_ryokan = "game/images/kyoto_ryokan.png"
image bg kyoto_izakaya = "game/images/kyoto_izakaya.png"

image waiter neutral = "game/images/waiter_neutral.png"
image waiter distant = "game/images/waiter_distant.png"


# =========================================
# INICIO
# =========================================

label start:

    jump agent_manager


# =========================================
# AGENT MANAGER
# =========================================

label agent_manager:

    $ social_credit = 0
    $ tatemae_balance = 0
    $ politeness_score = 0
    $ scenes_passed = 0

    jump scene_01_start


# =========================================
# ESCENA 1 — RYOKAN
# =========================================

label scene_01_start:

    scene bg kyoto_ryokan
    show waiter neutral

    "El anfitrión del ryokan te trae las toallas para el baño."

    waiter "こちら、お風呂のご用意でございます。ごゆっくりどうぞ。"

    "Aquí tiene lo necesario para el baño. Disfrútelo tranquilamente."

    "Al desdoblar la toalla, ves una mancha evidente."

    menu:

        "¿Cómo respondes?"

        "Esta toalla está sucia. Tráigame otra.":

            $ social_credit -= 2
            $ tatemae_balance -= 2

            jump s01_bad


        "Sumimasen, kono taoru, sukoshi ki ni naru ten ga atte...":

            "Disculpe, esta toalla tiene algo que me preocupa un poco..."

            $ social_credit += 2
            $ tatemae_balance += 2
            $ politeness_score += 2

            jump s01_good


        "Daijoubu desu... (Decides usarla igualmente).":

            $ social_credit -= 1
            $ tatemae_balance += 1

            jump s01_neutral


label s01_bad:

    show waiter distant

    waiter "…かしこまりました。"

    "…Entendido."

    "El ambiente se vuelve frío e incómodo."

    $ objective_completed = False

    jump scene_01_end


label s01_good:

    show waiter neutral

    waiter "ああ、大変失礼いたしました。"

    "Oh, le pido disculpas."

    "El anfitrión cambia la toalla inmediatamente."

    $ objective_completed = True
    $ scenes_passed += 1

    jump scene_01_end


label s01_neutral:

    show waiter neutral

    waiter "ごゆっくりどうぞ。"

    "Disfrútelo tranquilamente."

    "Decides no decir nada."

    $ objective_completed = False

    jump scene_01_end


label scene_01_end:

    "ESCENA 1 - RESULTADO"

    if objective_completed and social_credit >= 2:

        "Has manejado la situación con delicadeza."

    elif social_credit < 0:

        "Has sido demasiado directo para un ryokan tradicional."

    else:

        "Tu respuesta fue educada, pero no resolviste el problema."

    "Social Credit: [social_credit]"
    "Tatemae: [tatemae_balance]"
    "Cortesía: [politeness_score]"

    jump scene_02_start


# =========================================
# ESCENA 2 — IZAKAYA
# =========================================

label scene_02_start:

    scene bg kyoto_izakaya
    show waiter neutral

    "El camarero te trae la cuenta."

    waiter "お会計でございます。"

    "Aquí tiene la cuenta."

    "Notas un plato que no pediste."

    menu:

        "¿Qué haces?"

        "Esto está mal.":

            $ social_credit -= 2
            $ tatemae_balance -= 2

            jump s02_bad


        "Sumimasen, chotto kakunin shite mo yoroshii deshou ka?":

            "Disculpe, ¿podría verificarlo un momento?"

            $ social_credit += 2
            $ tatemae_balance += 2
            $ politeness_score += 2

            jump s02_good


        "Daijoubu desu. (Pagas sin decir nada).":

            $ social_credit -= 1

            jump s02_neutral


label s02_bad:

    show waiter distant

    waiter "申し訳ございません。"

    "Lo siento."

    "El camarero corrige la cuenta en silencio."

    $ objective_completed = False

    jump scene_02_end


label s02_good:

    show waiter neutral

    waiter "失礼いたしました。"

    "Disculpe el error."

    "La situación se resuelve cordialmente."

    $ objective_completed = True
    $ scenes_passed += 1

    jump scene_02_end


label s02_neutral:

    show waiter neutral

    waiter "ありがとうございます。"

    "Gracias."

    "Pagas de más para evitar conflicto."

    $ objective_completed = False

    jump scene_02_end


label scene_02_end:

    "ESCENA 2 - RESULTADO"

    if objective_completed and social_credit >= 2:

        "Has equilibrado cortesía e indirección correctamente."

    elif social_credit < 0:

        "Tu tono resultó demasiado agresivo."

    else:

        "Fuiste educado, pero poco efectivo."

    "Social Credit: [social_credit]"
    "Tatemae: [tatemae_balance]"
    "Cortesía: [politeness_score]"

    jump scene_03_start


# =========================================
# ESCENA 3 — SALÓN DE TÉ
# =========================================

label scene_03_start:

    scene bg kyoto_tea_room
    show waiter neutral

    "El menú está completamente en japonés."

    waiter "ご注文はお決まりでしょうか？"

    "¿Ya sabe lo que va a tomar?"

    menu:

        "¿Cómo respondes?"

        "No entiendo nada. ¿Tiene menú en inglés?":

            $ social_credit -= 2
            $ tatemae_balance -= 1

            jump s03_bad


        "Sumimasen, osusume wa nandeshou ka?":

            "Disculpe, ¿qué me recomienda?"

            $ social_credit += 2
            $ tatemae_balance += 2
            $ politeness_score += 2

            jump s03_good


        "Kore wo kudasai. (Señalas uno al azar).":

            $ social_credit -= 1

            jump s03_neutral


label s03_bad:

    show waiter distant

    waiter "英語のメニューはございません。"

    "No tenemos menú en inglés."

    "La situación se vuelve incómoda."

    $ objective_completed = False

    jump scene_03_end


label s03_good:

    show waiter neutral

    waiter "こちらの煎茶はいかがでしょうか。"

    "¿Qué le parece este sencha?"

    "El camarero te explica varias opciones con entusiasmo."

    $ objective_completed = True
    $ scenes_passed += 1

    jump scene_03_end


label s03_neutral:

    show waiter neutral

    waiter "かしこまりました。"

    "Entendido."

    "Te sirven algo al azar."

    $ objective_completed = False

    jump scene_03_end


label scene_03_end:

    "ESCENA 3 - RESULTADO"

    if objective_completed and social_credit >= 2:

        "Has generado una interacción positiva."

    elif social_credit < 0:

        "Tu actitud rompió la atmósfera tradicional."

    else:

        "Tu respuesta fue correcta, pero distante."

    "Social Credit: [social_credit]"
    "Tatemae: [tatemae_balance]"
    "Cortesía: [politeness_score]"

    jump final_score


# =========================================
# RESULTADO FINAL
# =========================================

label final_score:

    "FIN DE LA SESIÓN"

    if scenes_passed == 3:

        "Has dominado la comunicación indirecta japonesa."

    elif scenes_passed == 2:

        "Buen trabajo. Tu nivel social es sólido."

    elif scenes_passed == 1:

        "Todavía tiendes a la franqueza occidental."

    else:

        "La cortesía japonesa requiere más práctica."

    ""

    "Social Credit Final: [social_credit]"
    "Tatemae Final: [tatemae_balance]"
    "Cortesía Final: [politeness_score]"

    return