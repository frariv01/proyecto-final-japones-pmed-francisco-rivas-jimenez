# =========================================
# MISTERIO EN KIOTO (B2)
# =========================================

# ---------- VARIABLES ----------
default social_credit = 0        # Sistema oculto principal
default tatemae_balance = 0      # Nivel de indirección
default politeness_score = 0     # Nivel de cortesía
default objective_completed = False

# ---------- PERSONAJES ----------
define waiter = Character("Camarero", color="#6b4f3a")

# ---------- ASSETS ----------
image bg kyoto_tea_room = "kyoto_tea_room.png"
image waiter neutral = "waiter_neutral.png"
image waiter distant = "waiter_distant.png"

# ---------- START ----------
label start:
    jump agent_manager_scene_kyoto_tea

# ---------- AGENT MANAGER ----------
label agent_manager_scene_kyoto_tea:

    # Metadata (escalabilidad futura)
    $ scene_id = "kyoto_tea_error"
    $ difficulty_level = "B2"
    $ learning_focus = ["indirectness", "politeness", "social cues"]

    jump scene_kyoto_tea_start

# ---------- ESCENA PRINCIPAL ----------
label scene_kyoto_tea_start:

    scene bg kyoto_tea_room

    show waiter neutral

    "El camarero deja el té frente a ti con una leve reverencia."

    waiter "お待たせいたしました。こちら、ご注文のお茶でございます。"

    "Notas inmediatamente que no es lo que pediste."

    menu:
        "¿Cómo respondes?"

        "Esto no es lo que pedí.":
            $ social_credit -= 2
            $ tatemae_balance -= 2
            $ politeness_score += 0

            "Esto no es lo que pedí."
            jump reaction_bad

        "Sumimasen, chotto kakunin shite mo ii desu ka? Watashi no chuumon wa matcha datta you na ki ga shimasu ga...":
            $ social_credit += 2
            $ tatemae_balance += 2
            $ politeness_score += 2

            jump reaction_good

        "Ah... daijoubu desu...":
            $ social_credit -= 1
            $ tatemae_balance += 1
            $ politeness_score += 1

            jump reaction_neutral

# ---------- REACCIONES ----------
label reaction_bad:

    show waiter distant

    waiter "申し訳ございませんが、こちらはご注文通りかと存じます。"

    "El ambiente se vuelve incómodo."

    $ objective_completed = False
    jump scene_end


label reaction_good:

    show waiter neutral

    waiter "ああ、失礼いたしました。すぐにお取り替えいたします。"

    "El camarero sonríe levemente. Has manejado bien la situación."

    $ objective_completed = True
    jump scene_end


label reaction_neutral:

    show waiter neutral

    waiter "ご満足いただければ幸いでございます。"

    "No corriges el error."

    $ objective_completed = False
    jump scene_end

# ---------- RESULTADO ----------
label scene_end:

    if objective_completed and social_credit >= 2:
        "Has dominado el equilibrio entre cortesía e indirección."
    elif social_credit < 0:
        "Has sido demasiado directo para el contexto japonés."
    else:
        "Tu respuesta fue educada, pero no efectiva."

    "Social Credit: [social_credit]"
    "Tatemae: [tatemae_balance]"
    "Cortesía: [politeness_score]"

    return