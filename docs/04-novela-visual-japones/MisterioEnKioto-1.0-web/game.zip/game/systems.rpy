# game/systems.rpy

# --- Perfil del Estudiante ---
default student_name = "Alex"
default current_level = "B2"

# --- Sistema de Tatemae (Crédito Social Japonés) ---
# Empieza en 50, baja si eres directo/rudo, sube si eres indirecto/cortés
default tatemae_score = 50

# --- Personajes ---
define player = Character("[student_name]", color="#42f575")
define waiter = Character("Camarero", color="#f5b942")

# Función útil para mostrar notificaciones de cambio de Tatemae (opcional, para UI)
# Por ahora lo gestionaremos de forma invisible en la narrativa.
