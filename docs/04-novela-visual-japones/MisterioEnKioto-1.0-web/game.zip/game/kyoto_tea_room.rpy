# game/kyoto_tea_room.rpy

label kyoto_tea_room:
    
    # Marcadores de posición para audio (asegúrate de añadir los archivos a game/audio/)
    # play music "audio/rain_kyoto.ogg" fadein 2.0
    
    scene bg_tea_room_rain with dissolve

    "El suave sonido de la lluvia de Kioto repiquetea contra el cristal."
    "Llevas un rato esperando en este tradicional salón de té. Pediste un exquisito Matcha caliente para relajarte."
    
    # play sound "audio/teacup_clink.ogg"
    "Un camarero apresurado se acerca a tu mesa, deja una bandeja rápidamente y hace una pequeña reverencia."
    
    show waiter at center
    
    waiter "O-matase itashimashita."
    waiter "Aquí tiene su té. Disfrútelo."
    
    "El camarero se da la vuelta para atender a otra mesa."
    "Miras la taza. El líquido es de un verde amarillento translúcido... Esto no es Matcha denso y espumoso. Es Sencha."
    "Debes llamarlo y corregir el pedido, pero está claramente abrumado de trabajo. Recuerda las reglas del 'Tatemae': la confrontación directa se considera ruda."

    menu:
        # Opción 1: Directa (Falla el Tatemae)
        "Sumimasen. Este no es mi pedido. Pedí Matcha." (tooltip="Directo e impositivo. No recomendado para B2."):
            $ tatemae_score -= 10
            
            player "Sumimasen. Este no es mi pedido. Pedí Matcha."
            
            "El camarero se detiene en seco. Su expresión se tensa por una fracción de segundo antes de componer su máscara formal."
            
            waiter "Ah. Mis disculpas. Enseguida se lo cambio."
            
            "Recoge la taza con movimientos rígidos. Has resuelto el problema, pero la atmósfera se ha vuelto gélida."
            "En la cultura japonesa, señalar el error de alguien directamente cuando están ocupados puede hacerles 'perder la cara'."
            "Tu nivel de Tatemae ha disminuido. [tatemae_score]/100."
            
        # Opción 2: Indirecta pero poco empática
        "Sumimasen, creo que se ha equivocado de té." (tooltip="Más suave, pero sigue culpando directamente al interlocutor."):
            $ tatemae_score -= 5
            
            player "Sumimasen, creo que se ha equivocado de té."
            
            "El camarero se gira lentamente. Mira la taza."
            
            waiter "Tiene razón. Lo siento."
            
            "Lo cambia, pero notas que su servicio posterior es mínimo y apresurado. Sigue siendo demasiado directo."
            "Tu nivel de Tatemae ha disminuido. [tatemae_score]/100."
            
        # Opción 3: Indirecta, empática y usando vocabulario B2 (Éxito de Tatemae)
        "O-isogashii tokoro moshiwake arimasen. Chotto... pedí Matcha, pero parece que esto es Sencha." (tooltip="Avanzado. Demuestra empatía por su tiempo y usa 'Chotto' para suavizar."):
            $ tatemae_score += 15
            
            player "O-isogashii tokoro moshiwake arimasen. Chotto..."
            
            "El camarero se gira de inmediato, su postura de 'trabajo' se relaja un poco al escuchar tu cortesía."
            
            waiter "Sí, ¿ocurre algo?"
            
            player "Pedí Matcha, pero parece que esto es Sencha."
            
            "Al no culparle directamente y usar 'parece que', le has dado una salida."
            "Los ojos del camarero se abren ligeramente y hace una reverencia más profunda y sincera."
            
            waiter "¡Oh! Le ruego me disculpe. Enseguida le traigo su Matcha. Gracias por su paciencia."
            
            "El camarero se retira con la bandeja. Al volver con tu Matcha, te ofrece un pequeño dulce tradicional (wagashi) de cortesía."
            "Has navegado perfectamente el 'Tatemae'. Has conseguido tu objetivo sin romper la armonía social."
            "Tu nivel de Tatemae ha aumentado. [tatemae_score]/100."

    "Te sientas a disfrutar de la vista de la lluvia, reflexionando sobre las sutilezas del idioma."
    
    return
